import random
import matplotlib.pyplot as plt

def tcp_tahoe_simulation(num_transmissions=100):
    cwnd = 1  # Ventana de congestión inicial
    history = []  # Para registrar la evolución de cwnd
    cwnd_values = []  # Para análisis estadístico
    loss_count = 0  # Contador de pérdidas

    for i in range(1, num_transmissions + 1):
        if random.random() < 0.8:  # 80% de probabilidad de éxito
            cwnd += 1
            resultado = "Éxito"
        else:  # 20% de probabilidad de pérdida
            cwnd = 1
            resultado = "Pérdida"
            loss_count += 1

        history.append(f"Transmisión {i}: {resultado} - cwnd = {cwnd}")
        cwnd_values.append(cwnd)

    return history, cwnd_values, loss_count

# Ejecutar la simulación
resultado_simulacion, cwnd_values, loss_count = tcp_tahoe_simulation()

# Imprimir la evolución de cwnd
for linea in resultado_simulacion:
    print(linea)

# Análisis estadístico
average_cwnd = sum(cwnd_values) / len(cwnd_values)
max_cwnd = max(cwnd_values)
print(f"\nAnálisis Estadístico:")
print(f"Promedio de cwnd: {average_cwnd:.2f}")
print(f"Máximo cwnd alcanzado: {max_cwnd}")
print(f"Número de pérdidas: {loss_count}")

# Visualización
plt.plot(cwnd_values, marker='o', linestyle='-')
plt.xlabel("Transmisión")
plt.ylabel("Tamaño de cwnd")
plt.title("Evolución de la ventana de congestión TCP Tahoe")
plt.grid()
plt.show()
